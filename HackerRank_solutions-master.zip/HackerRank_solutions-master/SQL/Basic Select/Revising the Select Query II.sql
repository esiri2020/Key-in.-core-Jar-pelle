-- Author: Rodney Shaghoulian
-- Github: github.com/RodneyShag

SELECT NAME FROM CITY
WHERE COUNTRYCODE = 'USA' AND POPULATION > 120000;
