-- Author: Rodney Shaghoulian
-- Github: github.com/RodneyShag

SELECT * FROM CITY;
