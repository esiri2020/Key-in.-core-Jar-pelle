-- Author: Rodney Shaghoulian
-- Github: github.com/RodneyShag

SELECT CITY, STATE FROM STATION;
