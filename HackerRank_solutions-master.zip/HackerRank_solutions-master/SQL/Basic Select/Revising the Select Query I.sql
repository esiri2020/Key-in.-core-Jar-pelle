-- Author: Rodney Shaghoulian
-- Github: github.com/RodneyShag

SELECT * FROM CITY
WHERE COUNTRYCODE = 'USA' AND POPULATION > 100000;
