-- Author: Rodney Shaghoulian
-- Github: github.com/RodneyShag

SELECT MAX(POPULATION) - MIN(POPULATION)
FROM CITY;
