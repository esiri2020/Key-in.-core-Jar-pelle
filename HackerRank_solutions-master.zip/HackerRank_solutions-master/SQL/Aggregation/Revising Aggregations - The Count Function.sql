-- Author: Rodney Shaghoulian
-- Github: github.com/RodneyShag

SELECT COUNT(*) FROM CITY
WHERE POPULATION > 100000;
