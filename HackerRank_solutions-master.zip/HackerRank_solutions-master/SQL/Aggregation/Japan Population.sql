-- Author: Rodney Shaghoulian
-- Github: github.com/RodneyShag

SELECT SUM(POPULATION) FROM CITY
WHERE COUNTRYCODE = 'JPN';
