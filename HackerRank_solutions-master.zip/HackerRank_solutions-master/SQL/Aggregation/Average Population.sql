-- Author: Rodney Shaghoulian
-- Github: github.com/RodneyShag

SELECT FLOOR(AVG(POPULATION))
FROM CITY;
